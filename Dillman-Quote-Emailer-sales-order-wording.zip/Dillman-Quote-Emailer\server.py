# server.py
import os, json, requests, traceback, re, base64, io, logging, uuid, html
from time import perf_counter
from datetime import datetime
from flask import Flask, request, jsonify, abort, make_response

# -------------------- Email & App Config --------------------
SEND_TO = os.getenv("SEND_TO", "shane@dillmanfarm.com")
SEND_FROM = os.getenv("SEND_FROM", "dillman@dillmanfarm.com")

# Always BCC these
BCC_DEFAULT = [e.strip() for e in os.getenv(
    "BCC_ADDRESSES",
    "dillman@dillmanfarm.com,shane@dillmanfarm.com"
).split(",") if e.strip()]

# CC customer automatically if true
CC_CUSTOMER = os.getenv("CC_CUSTOMER", "true").lower() == "true"

# SMTP2GO API (REQUIRED)
SMTP2GO_API_KEY = (os.getenv("SMTP2GO_API_KEY", "") or "").strip()
SMTP2GO_API_URL = (os.getenv("SMTP2GO_API_URL", "https://api.smtp2go.com/v3/email/send") or "").strip()
SMTP2GO_API_TIMEOUT = int(os.getenv("SMTP2GO_API_TIMEOUT", "20"))  # seconds

# reCAPTCHA
RECAPTCHA_SECRET = os.getenv("RECAPTCHA_SECRET", "")
RECAPTCHA_MIN_SCORE = float(os.getenv("RECAPTCHA_MIN_SCORE", "0.5"))

# Hard-coded: do NOT fast-ack. Only return "sent" if the email actually sends.
FAST_ACK = False

# -------------------- Journaling (diskless-safe) --------------------
JOURNAL_ENABLE = os.getenv("JOURNAL_ENABLE", "true").lower() == "true"
_env_jdir = (os.getenv("JOURNAL_DIR", "") or "").strip()
_default_jdir = "/tmp/journal"
JOURNAL_DIR = _env_jdir or _default_jdir
try:
    os.makedirs(JOURNAL_DIR, exist_ok=True)
except Exception:
    JOURNAL_DIR = _default_jdir
    try:
        os.makedirs(JOURNAL_DIR, exist_ok=True)
    except Exception:
        JOURNAL_ENABLE = False  # last resort

def _journal_file_for_today() -> str:
    return os.path.join(JOURNAL_DIR, f"quotes-{datetime.utcnow().strftime('%Y-%m-%d')}.jsonl")

def journal_append(entry: dict):
    if not JOURNAL_ENABLE:
        return
    entry = dict(entry)
    entry["journal_ts"] = datetime.utcnow().isoformat() + "Z"
    try:
        with open(_journal_file_for_today(), "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass  # never crash request on journal failure

def journal_status(qid: str, stage: str, detail: str = ""):
    journal_append({"id": qid, "stage": stage, "detail": (detail or "")[:1000]})

# -------------------- App --------------------
app = Flask(__name__)
app.logger.setLevel(logging.INFO)

# -------------------- CORS --------------------
ALLOWED_ORIGINS = [o.strip().lower() for o in os.getenv(
    "ALLOWED_ORIGINS",
    "https://dillmanfarm.com,https://www.dillmanfarm.com"
).split(",") if o.strip()]

ALLOWED_ORIGINS_REGEX = os.getenv(
    "ALLOWED_ORIGINS_REGEX",
    r"^https:\/\/([a-z0-9-]+\.)?dillmanfarm\.com$"
)

def _origin_allowed(origin: str) -> bool:
    if not origin:
        return False
    o = origin.strip().lower()
    if o in ALLOWED_ORIGINS:
        return True
    try:
        return bool(re.match(ALLOWED_ORIGINS_REGEX, o))
    except re.error:
        return False

def cors_ok(resp):
    origin = (request.headers.get("Origin") or "").strip().lower()
    if _origin_allowed(origin):
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS, GET"
    return resp

@app.after_request
def add_cors_headers(resp):
    return cors_ok(resp)

@app.route("/submit-quote", methods=["OPTIONS"])
def preflight():
    return cors_ok(make_response("", 204))

# -------------------- Validation / Request Type --------------------
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")

def _request_type(data) -> str:
    raw = str(data.get("request_type") or data.get("type") or data.get("form_type") or "").strip().lower()
    if raw in ("sample", "sample_request", "sample-request"):
        return "sample_request"

    for key in ("zone", "tier", "action"):
        marker = str(data.get(key, "") or "").strip().lower().replace("-", " ").replace("_", " ")
        if marker in ("sample", "sample request"):
            return "sample_request"

    return "quote"

def _get_requested_by(data) -> str:
    return str(data.get("requested_by") or data.get("company") or data.get("name") or "").strip()

def _get_shipping_address(data) -> str:
    direct = (
        data.get("shipping_address")
        or data.get("shippingAddress")
        or data.get("ship_to")
        or data.get("shipTo")
        or data.get("shipping")
        or data.get("ship_address")
        or data.get("sample_address")
        or data.get("delivery_address")
        or data.get("full_address")
    )
    has_address_parts = any(data.get(k) for k in (
        "address", "street", "street_address", "address1", "address_line1",
        "address2", "address_line2", "city", "ship_state", "shipping_state",
        "state", "zip", "zipcode", "postal_code",
    ))
    if direct and not has_address_parts:
        return str(direct).strip()

    street = str(
        direct
        or data.get("address")
        or data.get("street")
        or data.get("street_address")
        or data.get("address1")
        or data.get("address_line1")
        or ""
    ).strip()
    address2 = str(data.get("address2") or data.get("address_line2") or "").strip()
    city = str(data.get("city") or "").strip()
    state = str(data.get("ship_state") or data.get("shipping_state") or data.get("state") or "").strip()
    postal = str(data.get("zip") or data.get("zipcode") or data.get("postal_code") or "").strip()

    lines = [line for line in (street, address2) if line]
    city_state_zip = " ".join(part for part in (city, state, postal) if part)
    if city_state_zip and (street or city or postal):
        lines.append(city_state_zip)
    return "\n".join(lines).strip()

def validate_quote_payload(data):
    required = ["company", "contact", "email", "state", "zone", "tier", "phys", "eq", "grand", "items", "recaptcha"]
    for k in required:
        if k not in data:
            abort(400, description=f"Missing field: {k}")

    if not EMAIL_RE.match(str(data.get("email", "")).strip()):
        abort(400, description="Invalid email")

    if not isinstance(data["items"], list) or len(data["items"]) == 0:
        abort(400, description="No items in cart")

    if len(json.dumps(data)) > 200_000:
        abort(413, description="Payload too large")

def validate_sample_payload(data):
    required = ["contact", "items", "recaptcha"]
    for k in required:
        if k not in data:
            abort(400, description=f"Missing field: {k}")

    if not _get_requested_by(data):
        abort(400, description="Missing field: requested_by")
    if not str(data.get("contact", "")).strip():
        abort(400, description="Missing field: contact")
    if not str(_get_shipping_address(data)).strip():
        abort(400, description="Missing field: shipping_address")

    email = str(data.get("email", "")).strip()
    if email and not EMAIL_RE.match(email):
        abort(400, description="Invalid email")

    if not isinstance(data["items"], list) or len(data["items"]) == 0:
        abort(400, description="No sample items selected")

    if len(json.dumps(data)) > 200_000:
        abort(413, description="Payload too large")

def verify_recaptcha(token, allowed_actions=None):
    if not RECAPTCHA_SECRET:
        app.logger.warning("reCAPTCHA SECRET not set; allowing request in dev.")
        return True, {"dev": "no-secret"}

    try:
        r = requests.post(
            "https://www.google.com/recaptcha/api/siteverify",
            data={
                "secret": RECAPTCHA_SECRET,
                "response": token,
                "remoteip": request.headers.get("X-Forwarded-For", request.remote_addr),
            },
            timeout=10,
        )
        data = r.json()
    except Exception as e:
        app.logger.exception("reCAPTCHA verify call failed")
        return False, {"error": str(e)}

    ok = bool(data.get("success"))
    score = float(data.get("score", 0.0))
    action = data.get("action")

    allowed_actions = [a for a in (allowed_actions or []) if a]
    if allowed_actions and action and action not in allowed_actions:
        ok = False

    if score < RECAPTCHA_MIN_SCORE:
        ok = False

    if not ok:
        app.logger.warning(f"reCAPTCHA not ok: {data}")

    return ok, data

# -------------------- Helpers --------------------
def _sanitize_text(t: str) -> str:
    s = (t or "").replace("\t", " ").replace("\r", " ").replace("\n", " ").strip()
    return s[:2000]

def _sanitize_multiline_text(t: str) -> str:
    t = str(t or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    lines = [line.strip() for line in t.split("\n")]
    lines = [line for line in lines if line]
    return "\n".join(lines)[:4000]

def _pdf_text(t: str) -> str:
    return html.escape(str(t or "")).replace("\n", "<br/>")

def _to_money(s) -> float:
    if s is None:
        return 0.0
    if isinstance(s, (int, float)):
        return float(s)
    s = re.sub(r"[^0-9.\-]", "", str(s))
    try:
        return float(s) if s else 0.0
    except ValueError:
        return 0.0

def _to_qty(s) -> float:
    if s is None:
        return 0.0
    if isinstance(s, (int, float)):
        return float(s)
    s = re.sub(r"[^0-9.\-]", "", str(s))
    try:
        return float(s) if s else 0.0
    except ValueError:
        return 0.0

def _sample_qty(it) -> int:
    raw = it.get("qty", 1)
    if raw in (None, ""):
        raw = 1
    qty = int(_to_qty(raw))
    return qty if qty > 0 else 1

# -------------------- Plain Text Email Bodies --------------------
def build_quote_plain_text(data):
    lines = []
    lines.append(f"Sales Order — {data.get('company', '')}")
    lines.append(f"Contact: {data.get('contact', '')} | {data.get('email', '')}")
    lines.append(f"State: {data.get('state', '')} | Zone: {data.get('zone', '')} | Tier: {data.get('tier', '')}")

    ship_addr = _get_shipping_address(data)
    if ship_addr:
        lines.append("Shipping Address:")
        lines.append(ship_addr)

    lines.append(f"Total Cases (physical): {data.get('phys', 0)}")
    lines.append(f"Total Cases (6-pack eq): {data.get('eq', 0)}")
    lines.append(f"Estimated Total: ${data.get('grand', '0.00')}")
    ship_meth = IIF_SHIPVIA_LTL if int(data.get("eq", 0)) >= IIF_LTL_THRESHOLD else IIF_SHIPVIA_UPS
    lines.append(f"Ship Method: {ship_meth}")
    lines.append("")
    lines.append("Items:")

    for it in data["items"]:
        lines.append(
            f" - Qty {it.get('qty', 0)} | {it.get('sku', '')} | {it.get('desc', '')} | "
            f"{it.get('pack', '')} | {it.get('oz', '')} oz | {it.get('unit', '$0.00')} | {it.get('line', '$0.00')}"
        )

    if data.get("notes"):
        lines.append("")
        lines.append("Notes:")
        lines.append(str(data["notes"]))

    return "\n".join(lines)

def build_sample_plain_text(data):
    lines = []
    lines.append(f"Sample Request — {_get_requested_by(data)}")
    lines.append(f"Name: {data.get('contact', '')}")
    lines.append(f"Email: {data.get('email', '')}")
    lines.append(f"Phone: {data.get('phone', '')}")
    lines.append("Shipping Address:")
    lines.append(_get_shipping_address(data) or "")
    lines.append(f"Total Samples: {sum(_sample_qty(it) for it in data['items'])}")

    if data.get("notes"):
        lines.append("")
        lines.append("Notes:")
        lines.append(str(data.get("notes", "")).strip())

    lines.append("")
    lines.append("Requested Samples:")
    for it in data["items"]:
        qty = _sample_qty(it)
        lines.append(f" - Qty {qty} | {it.get('sku', '')} | {it.get('desc', '')}")

    return "\n".join(lines)

# -------------------- CSV --------------------
def build_csv_bytes(data):
    rows = ["qty,sku,description,pack,ounces,case_price,line_total"]
    for it in data["items"]:
        qty = int(_to_qty(it.get("qty", 0)))
        if qty <= 0:
            continue
        desc = (it.get("desc", "") or "").replace('"', '""')
        rows.append(",".join([
            str(qty),
            str(it.get("sku", "")).replace(",", " "),
            f"\"{desc}\"",
            str(it.get("pack", "")).replace(",", " "),
            str(it.get("oz", "")).replace(",", " "),
            str(it.get("unit", "")).replace(",", " "),
            str(it.get("line", "")).replace(",", " "),
        ]))
    return ("\n".join(rows)).encode("utf-8")

# -------------------- IIF: QuickBooks Desktop SALES ESTIMATE --------------------
IIF_TOPRINT = os.getenv("IIF_TOPRINT", "true").lower() == "true"
IIF_DEFAULT_TERMS = os.getenv("IIF_TERMS", "")
IIF_DEFAULT_CLASS = os.getenv("IIF_CLASS", "")
IIF_TAXABLE_DEFAULT = os.getenv("IIF_TAXABLE_DEFAULT", "N").upper()
IIF_REF_PREFIX = os.getenv("IIF_REF_PREFIX", "WEBQ")
IIF_LTL_THRESHOLD = int(os.getenv("IIF_LTL_THRESHOLD", "30"))
IIF_SHIPVIA_UPS = os.getenv("IIF_SHIPVIA_UPS", "UPS")
IIF_SHIPVIA_LTL = os.getenv("IIF_SHIPVIA_LTL", "LTL")

def build_iif_bytes_estimate(data):
    today = datetime.now().strftime("%m/%d/%Y")
    refnum = f"{IIF_REF_PREFIX}-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"
    customer = _sanitize_text(data.get("company") or "Web Customer")
    contact = _sanitize_text(data.get("contact") or "")
    email = _sanitize_text(data.get("email") or "")
    state = _sanitize_text(data.get("state") or "")
    ship_meth = IIF_SHIPVIA_LTL if int(data.get("eq", 0)) >= IIF_LTL_THRESHOLD else IIF_SHIPVIA_UPS
    memo_hdr = f"{contact} {email} {state}".strip()

    out = []
    out.append("!TRNS\tTRNSID\tTRNSTYPE\tDATE\tACCNT\tNAME\tCLASS\tAMOUNT\tDOCNUM\tMEMO\tTOPRINT\tTERMS\tADDR1\tADDR2\tADDR3\tADDR4\tADDR5\tSHIPVIA\tTAXABLE")
    out.append("!SPL\tSPLID\tTRNSTYPE\tDATE\tACCNT\tNAME\tCLASS\tAMOUNT\tDOCNUM\tMEMO\tQNTY\tPRICE\tINVITEM\tOTHER1\tOTHER2\tTAXABLE")
    out.append("!ENDTRNS")

    trns = [
        "TRNS", "", "Estimate", today,
        "Accounts Receivable",
        customer, IIF_DEFAULT_CLASS, "",
        refnum,
        memo_hdr,
        "Y" if IIF_TOPRINT else "N",
        IIF_DEFAULT_TERMS,
        customer, contact, email, state, "",
        ship_meth, IIF_TAXABLE_DEFAULT
    ]
    out.append("\t".join(trns))

    for it in data["items"]:
        qty = int(_to_qty(it.get("qty", 0)))
        if qty <= 0:
            continue
        sku = _sanitize_text(str(it.get("sku", "")))
        memo = _sanitize_text(it.get("desc", ""))
        price = f"{_to_money(it.get('unit', '0')):.2f}"
        spl = [
            "SPL", "", "Estimate", today,
            "", customer, IIF_DEFAULT_CLASS, "", refnum,
            memo, str(qty), price, sku, "", "", IIF_TAXABLE_DEFAULT
        ]
        out.append("\t".join(spl))

    out.append("ENDTRNS")
    return ("\n".join(out) + "\n").encode("utf-8")

# -------------------- PDF Helpers --------------------
def _reportlab_bits():
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib import colors as _colors
        return letter, getSampleStyleSheet, inch, SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, _colors
    except ImportError as e:
        raise RuntimeError("reportlab not installed. Add 'reportlab==3.6.13' to requirements.txt") from e

# -------------------- Quote PDF --------------------
def build_quote_pdf_bytes(data):
    letter, getSampleStyleSheet, inch, SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, _colors = _reportlab_bits()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=letter,
        leftMargin=0.6 * inch, rightMargin=0.6 * inch,
        topMargin=0.6 * inch, bottomMargin=0.6 * inch,
        title=f"Sales Order — {data.get('company', '')}"
    )
    styles = getSampleStyleSheet()
    story = []

    title = "Dillman Farm — Sales Order"
    sub = f"{_sanitize_text(data.get('company', ''))}"
    meta = f"Contact: {_sanitize_text(data.get('contact', ''))}  •  Email: {_sanitize_text(data.get('email', ''))}  •  State: {_sanitize_text(data.get('state', ''))}"
    tz = f"Price Tier: {_sanitize_text(data.get('tier', '—'))}  •  Zone: {_sanitize_text(data.get('zone', '—'))}"
    ship_meth = IIF_SHIPVIA_LTL if int(data.get('eq', 0)) >= IIF_LTL_THRESHOLD else IIF_SHIPVIA_UPS
    ship_line = f"Ship Method: {ship_meth}"

    story += [
        Paragraph(title, styles['Title']),
        Paragraph(sub, styles['Heading3']),
        Spacer(1, 6),
        Paragraph(meta, styles['BodyText']),
        Paragraph(tz, styles['BodyText']),
        Paragraph(ship_line, styles['BodyText']),
    ]

    ship_addr = _get_shipping_address(data)
    if ship_addr:
        story += [
            Spacer(1, 6),
            Paragraph("Shipping Address:", styles['Heading4']),
            Paragraph(_pdf_text(_sanitize_multiline_text(ship_addr)), styles['BodyText']),
        ]

    story += [Spacer(1, 10)]

    rows = [["Qty", "Code", "Description", "Pack", "Ounces", "Case Price", "Line"]]
    for it in data["items"]:
        qty = int(_to_qty(it.get("qty", 0)))
        if qty <= 0:
            continue
        rows.append([
            str(qty),
            _sanitize_text(str(it.get("sku", ""))),
            _sanitize_text(str(it.get("desc", ""))),
            _sanitize_text(str(it.get("pack", ""))),
            _sanitize_text(str(it.get("oz", ""))),
            _sanitize_text(str(it.get("unit", ""))),
            _sanitize_text(str(it.get("line", ""))),
        ])

    table = Table(rows, repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('FONT', (0, 0), (-1, 0), 'Helvetica-Bold', 10),
        ('TEXTCOLOR', (0, 0), (-1, 0), _colors.white),
        ('BACKGROUND', (0, 0), (-1, 0), _colors.HexColor('#111827')),
        ('GRID', (0, 0), (-1, -1), 0.3, _colors.HexColor('#e5e7eb')),
        ('FONT', (0, 1), (-1, -1), 'Helvetica', 9),
        ('ALIGN', (0, 1), (0, -1), 'CENTER'),
        ('ALIGN', (3, 1), (6, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [_colors.whitesmoke, _colors.HexColor('#f9fafb')]),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story += [table, Spacer(1, 12)]

    total_phys = int(_to_qty(data.get("phys", 0)))
    total_eq = int(_to_qty(data.get("eq", 0)))
    grand_str = str(data.get("grand", "0.00"))
    totals = f"Totals — Physical Cases: {total_phys} •  6-pack Eq: {total_eq} •  Estimated Total: ${grand_str}"
    story += [Paragraph(totals, styles['Heading4'])]

    notes = (data.get("notes") or "").strip()
    if notes:
        story += [
            Spacer(1, 8),
            Paragraph("Notes:", styles['Heading4']),
            Paragraph(_pdf_text(_sanitize_multiline_text(notes)), styles['BodyText'])
        ]

    doc.build(story)
    return buf.getvalue()

# -------------------- Sample PDF --------------------
def build_sample_pdf_bytes(data):
    letter, getSampleStyleSheet, inch, SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, _colors = _reportlab_bits()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=letter,
        leftMargin=0.6 * inch, rightMargin=0.6 * inch,
        topMargin=0.6 * inch, bottomMargin=0.6 * inch,
        title=f"Sample Request — {_get_requested_by(data)}"
    )
    styles = getSampleStyleSheet()
    sample_label_style = styles['BodyText'].clone('SampleLabel')
    sample_label_style.fontSize = 12
    sample_label_style.leading = 15
    story = []

    title = "Dillman Farm — Sample Request"
    requested_by = _sanitize_text(_get_requested_by(data))
    contact = _sanitize_text(data.get("contact", ""))
    email = _sanitize_text(data.get("email", ""))
    phone = _sanitize_text(data.get("phone", ""))
    ship_addr = _sanitize_multiline_text(_get_shipping_address(data))
    notes = _sanitize_multiline_text(data.get("notes", ""))

    story += [
        Paragraph(title, styles['Title']),
        Paragraph(f"<b>Requested By:</b> {_pdf_text(requested_by)}", sample_label_style),
        Spacer(1, 6),
        Paragraph(f"<b>Name:</b> {_pdf_text(contact)}", sample_label_style),
        Paragraph(f"<b>Email:</b> {_pdf_text(email)}", sample_label_style),
        Paragraph(f"<b>Phone:</b> {_pdf_text(phone)}", sample_label_style),
        Spacer(1, 6),
        Paragraph("<b>Shipping Address:</b>", sample_label_style),
        Paragraph(_pdf_text(ship_addr), styles['BodyText']),
        Spacer(1, 10),
    ]

    rows = [["Qty", "Code", "Description"]]
    for it in data["items"]:
        qty = _sample_qty(it)
        rows.append([
            str(qty),
            _sanitize_text(str(it.get("sku", ""))),
            _sanitize_text(str(it.get("desc", ""))),
        ])

    table = Table(rows, repeatRows=1, hAlign='LEFT', colWidths=[0.8 * inch, 1.1 * inch, 4.9 * inch])
    table.setStyle(TableStyle([
        ('FONT', (0, 0), (-1, 0), 'Helvetica-Bold', 10),
        ('TEXTCOLOR', (0, 0), (-1, 0), _colors.white),
        ('BACKGROUND', (0, 0), (-1, 0), _colors.HexColor('#111827')),
        ('GRID', (0, 0), (-1, -1), 0.3, _colors.HexColor('#e5e7eb')),
        ('FONT', (0, 1), (-1, -1), 'Helvetica', 9),
        ('ALIGN', (0, 1), (1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [_colors.whitesmoke, _colors.HexColor('#f9fafb')]),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story += [table]

    if notes:
        story += [
            Spacer(1, 10),
            Paragraph("<b>Notes:</b>", sample_label_style),
            Paragraph(_pdf_text(notes), styles['BodyText'])
        ]

    doc.build(story)
    return buf.getvalue()

# -------------------- Email sender (SMTP2GO API) --------------------
def send_email(subject, body, to, cc=None, bcc=None, attachments=None, logger=None):
    """
    Sends via SMTP2GO HTTPS API (no SMTP sockets).
    attachments: list of tuples (filename, mime_main, mime_sub, bytes)
    """
    log = logger or app.logger

    if not SMTP2GO_API_KEY:
        raise RuntimeError("SMTP2GO_API_KEY not configured (Render env var)")

    def _uniq(emails):
        out = []
        seen = set()
        for e in (emails or []):
            e = (e or "").strip()
            if not e:
                continue
            k = e.lower()
            if k in seen:
                continue
            seen.add(k)
            out.append(e)
        return out

    all_cc = _uniq(cc or [])
    all_bcc = _uniq((bcc or []) + (BCC_DEFAULT or []))

    log.info(f"email.recipients to={to} cc={all_cc} bcc={_uniq(bcc or [])} bcc_default={BCC_DEFAULT}")
    log.info(f"email.path=api url={SMTP2GO_API_URL} timeout={SMTP2GO_API_TIMEOUT}s")

    payload = {
        "sender": SEND_FROM,
        "to": [to],
        "subject": subject,
        "text_body": body,
    }
    if all_cc:
        payload["cc"] = all_cc
    if all_bcc:
        payload["bcc"] = all_bcc

    if attachments:
        api_atts = []
        for (fname, main, sub, blob) in attachments:
            api_atts.append({
                "filename": fname,
                "fileblob": base64.b64encode(blob).decode("ascii"),
                "mimetype": f"{main}/{sub}",
            })
        payload["attachments"] = api_atts

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Smtp2go-Api-Key": SMTP2GO_API_KEY,
    }

    r = requests.post(SMTP2GO_API_URL, headers=headers, json=payload, timeout=SMTP2GO_API_TIMEOUT)

    if r.status_code >= 400:
        raise RuntimeError(f"SMTP2GO API HTTP {r.status_code}: {r.text[:2000]}")

    out = r.json() if r.content else {}
    data = out.get("data") or {}
    succeeded = int(data.get("succeeded", 0) or 0)
    failed = int(data.get("failed", 0) or 0)

    if failed > 0 or succeeded < 1:
        raise RuntimeError(f"SMTP2GO API send failed: {out}")

    log.info(f"email.api.result=ok request_id={out.get('request_id')} email_id={data.get('email_id')} succeeded={succeeded} failed={failed}")
    return

# -------------------- Endpoint --------------------
@app.post("/submit-quote")
def submit_quote():
    t0 = perf_counter()
    try:
        payload = request.get_json(silent=True) or {}
        app.logger.info(f"/submit-quote start size={len(json.dumps(payload))} FAST_ACK={FAST_ACK}")

        req_type = _request_type(payload)

        if req_type == "sample_request":
            validate_sample_payload(payload)
        else:
            validate_quote_payload(payload)

        request_id = payload.get("id") or uuid.uuid4().hex
        payload["id"] = request_id

        journal_append({"id": request_id, "stage": "received", "payload": payload})

        # Allow current quote page action="quote" and future sample page action="sample_request"
        t1 = perf_counter()
        ok, recap = verify_recaptcha(payload.get("recaptcha", ""), allowed_actions=["quote", "sample_request"])
        app.logger.info(f"timing.recaptcha={(perf_counter()-t1):.3f}s ok={ok} type={req_type}")
        if not ok:
            journal_status(request_id, "error", "recaptcha_failed")
            return cors_ok(jsonify({"ok": False, "error": "reCAPTCHA failed", "details": recap})), 400

        # Subject / body / attachments
        stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

        if req_type == "sample_request":
            subject = f"Sample Request — {_get_requested_by(payload) or 'Customer'} — {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"
            body = build_sample_plain_text(payload)

            t2 = perf_counter()
            sample_pdf_bytes = build_sample_pdf_bytes(payload)
            app.logger.info(f"timing.builds={(perf_counter()-t2):.3f}s sizes sample_pdf={len(sample_pdf_bytes)}")

            atts = [
                (f"Sample_Request_{stamp}.pdf", "application", "pdf", sample_pdf_bytes),
            ]
        else:
            subject = f"Sales Order — {payload.get('company', 'Customer')} — {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"
            body = build_quote_plain_text(payload)

            t2 = perf_counter()
            iif_bytes = build_iif_bytes_estimate(payload)
            csv_bytes = build_csv_bytes(payload)
            pdf_bytes = build_quote_pdf_bytes(payload)
            app.logger.info(f"timing.builds={(perf_counter()-t2):.3f}s sizes iif={len(iif_bytes)} csv={len(csv_bytes)} pdf={len(pdf_bytes)}")

            atts = [
                (f"Estimate_{stamp}.iif", "text", "plain", iif_bytes),
                ("quote.csv", "text", "csv", csv_bytes),
                (f"Sales_Order_{stamp}.pdf", "application", "pdf", pdf_bytes),
            ]

        # CC / BCC
        cc = []
        if CC_CUSTOMER and payload.get("email"):
            cc.append(payload["email"])
        for addr in (payload.get("cc_emails") or []):
            addr = (addr or "").strip()
            if addr:
                cc.append(addr)

        bcc = []
        for addr in (payload.get("bcc_emails") or []):
            addr = (addr or "").strip()
            if addr:
                bcc.append(addr)

        # NO FAST-ACK: only return success after email is actually accepted by SMTP2GO.
        journal_status(request_id, "processing", "emailing")
        t3 = perf_counter()

        try:
            app.logger.info(f"email.intent to={SEND_TO} cc={cc} bcc={bcc} fast_ack={FAST_ACK}")
            send_email(subject, body, SEND_TO, cc=cc, bcc=bcc, attachments=atts, logger=app.logger)
            app.logger.info(f"timing.email={(perf_counter()-t3):.3f}s")
            journal_status(request_id, "emailed", "ok")
        except Exception:
            app.logger.error("email.send failed:\n" + traceback.format_exc())
            journal_status(request_id, "error", "email_failed")
            app.logger.info(f"/submit-quote total={(perf_counter()-t0):.3f}s (FAILED)")
            return cors_ok(jsonify({"ok": False, "error": "Your order did not go through. Please try again."})), 500

        app.logger.info(f"/submit-quote total={(perf_counter()-t0):.3f}s")
        return cors_ok(jsonify({"ok": True, "status": "sent", "id": request_id}))

    except Exception:
        app.logger.error(f"/submit-quote error after {(perf_counter()-t0):.3f}s:\n" + traceback.format_exc())
        return cors_ok(jsonify({"ok": False, "error": "Server error"})), 500

@app.errorhandler(400)
@app.errorhandler(413)
def handle_err(e):
    resp = jsonify(ok=False, error=str(e))
    resp.status_code = getattr(e, "code", 500)
    return cors_ok(resp)

@app.get("/")
def health():
    return cors_ok(make_response("OK", 200))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8080")))
